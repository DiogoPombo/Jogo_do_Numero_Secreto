let AUTHOR = 'POMBO';
let AVATAR = '\\Õ/';
let MADE_BY = 'MADE BY:';
let SPACE = ' ';
console.log(MADE_BY + SPACE + AUTHOR + SPACE + SPACE + AVATAR);

// MADE BY: POMBO  \Õ/

console.log('Jogo do número secreto!')
alert('Boas vindas ao jogo do número secreto!');
let numero_secreto;
let chute;
let dificuldade = prompt('Selecione a dificuldade: [1 = Fácil] [2 = Médio] [3 = Difícil] [4 = Impossível]');
let tentativas;

while (dificuldade == null || dificuldade < 1 || dificuldade > 4) {
    alert('Opção inválida!')
   dificuldade = prompt('Selecione a dificuldade: [1 = Fácil] [2 = Médio] [3 = Difícil] [4 = Impossível]');
}
    
if (dificuldade == 1) {
   numero_secreto = parseInt((Math.random() * 10) + 1);
   tentativas = 9;
} else if (dificuldade == 2) {
    numero_secreto = parseInt((Math.random() * 50) + 1);
    tentativas = 25;
} else if (dificuldade == 3) {
   numero_secreto = parseInt((Math.random() * 100) + 1);
   tentativas = 10;
} else if (dificuldade == 4) {
    numero_secreto = parseInt((Math.random() * 1000000) + 1);
    tentativas = 1;
}

while(chute != numero_secreto && tentativas > 0) {
    if (dificuldade == 1) {
        chute = prompt(`Escolha o número entre 1 e 10, Você tem ${tentativas} tentativas`);
     } else if (dificuldade == 2) {
         chute = prompt(`Escolha o número entre 1 e 50, Você tem ${tentativas} tentativas`);
     } else if (dificuldade == 3) {
        chute = prompt(`Escolha o número entre 1 e 100, Você tem ${tentativas} tentativas`);
     } else if (dificuldade == 4) {
         chute = prompt('Escolha o número entre 1 e 1000000, você tem somente uma tentativa');
     }
     
     if (numero_secreto == chute) {
        alert(`Isso ai, você descobriu o número secreto ${numero_secreto}`);
     } else {
        if (numero_secreto > chute) {
            alert(`O número secreto é maior que ${chute}`);
        } else {
            alert(`O número secreto é menor que ${chute}`);
        }
        tentativas--;
        alert('Você errou :(');
     }
}
console.log(`Numero secreto: ${numero_secreto}`);

if (tentativas == 0) {
alert(`O número secreto era: ${numero_secreto}, mais sorte da próxima vez!`);
}